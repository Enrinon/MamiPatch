.class public Ljp/co/fwinc/madomagimamiTPS/AppliActivity;
.super Landroid/app/Activity;
.source "AppliActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ljp/co/fwinc/madomagimamiTPS/AppliActivity$MainThread;
    }
.end annotation


# static fields
.field public static final FRAME_WAIT:I = 0x21


# instance fields
.field private baseLayout:Landroid/widget/FrameLayout;

.field private glRender:Ljp/co/fwinc/madomagimamiTPS/GLRender;

.field private glSurfaceView:Landroid/opengl/GLSurfaceView;

.field private lastTime:J

.field private mainThread:Ljava/lang/Thread;

.field private progressDialog:Landroid/app/ProgressDialog;

.field private runWallpaper:Z

.field private threadStop:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 26
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method static synthetic access$0(Ljp/co/fwinc/madomagimamiTPS/AppliActivity;)Z
    .locals 1

    .prologue
    .line 50
    iget-boolean v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->threadStop:Z

    return v0
.end method

.method static synthetic access$1(Ljp/co/fwinc/madomagimamiTPS/AppliActivity;)J
    .locals 2

    .prologue
    .line 47
    iget-wide v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->lastTime:J

    return-wide v0
.end method

.method static synthetic access$10(Ljp/co/fwinc/madomagimamiTPS/AppliActivity;Z)V
    .locals 0

    .prologue
    .line 50
    iput-boolean p1, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->threadStop:Z

    return-void
.end method

.method static synthetic access$11(Ljp/co/fwinc/madomagimamiTPS/AppliActivity;Ljava/lang/Thread;)V
    .locals 0

    .prologue
    .line 41
    iput-object p1, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->mainThread:Ljava/lang/Thread;

    return-void
.end method

.method static synthetic access$2(Ljp/co/fwinc/madomagimamiTPS/AppliActivity;J)V
    .locals 0

    .prologue
    .line 47
    iput-wide p1, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->lastTime:J

    return-void
.end method

.method static synthetic access$3(Ljp/co/fwinc/madomagimamiTPS/AppliActivity;)Ljp/co/fwinc/madomagimamiTPS/GLRender;
    .locals 1

    .prologue
    .line 38
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glRender:Ljp/co/fwinc/madomagimamiTPS/GLRender;

    return-object v0
.end method

.method static synthetic access$4(Ljp/co/fwinc/madomagimamiTPS/AppliActivity;)Landroid/opengl/GLSurfaceView;
    .locals 1

    .prologue
    .line 35
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glSurfaceView:Landroid/opengl/GLSurfaceView;

    return-object v0
.end method

.method static synthetic access$5(Ljp/co/fwinc/madomagimamiTPS/AppliActivity;Landroid/app/ProgressDialog;)V
    .locals 0

    .prologue
    .line 44
    iput-object p1, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->progressDialog:Landroid/app/ProgressDialog;

    return-void
.end method

.method static synthetic access$6(Ljp/co/fwinc/madomagimamiTPS/AppliActivity;)Landroid/app/ProgressDialog;
    .locals 1

    .prologue
    .line 44
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->progressDialog:Landroid/app/ProgressDialog;

    return-object v0
.end method

.method static synthetic access$7(Ljp/co/fwinc/madomagimamiTPS/AppliActivity;Z)V
    .locals 0

    .prologue
    .line 53
    iput-boolean p1, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->runWallpaper:Z

    return-void
.end method

.method static synthetic access$8(Ljp/co/fwinc/madomagimamiTPS/AppliActivity;)Z
    .locals 1

    .prologue
    .line 53
    iget-boolean v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->runWallpaper:Z

    return v0
.end method

.method static synthetic access$9(Ljp/co/fwinc/madomagimamiTPS/AppliActivity;)Ljava/lang/Thread;
    .locals 1

    .prologue
    .line 41
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->mainThread:Ljava/lang/Thread;

    return-object v0
.end method


# virtual methods
.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 4
    .param p1, "event"    # Landroid/view/KeyEvent;

    .prologue
    const/4 v1, 0x1

    .line 152
    :try_start_0
    iget-object v2, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glRender:Ljp/co/fwinc/madomagimamiTPS/GLRender;

    if-eqz v2, :cond_0

    .line 153
    iget-object v2, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glRender:Ljp/co/fwinc/madomagimamiTPS/GLRender;

    invoke-virtual {v2, p1}, Ljp/co/fwinc/madomagimamiTPS/GLRender;->keyEvent(Landroid/view/KeyEvent;)V

    .line 157
    :cond_0
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v2

    if-nez v2, :cond_2

    .line 158
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v2

    const/4 v3, 0x4

    if-ne v2, v3, :cond_2

    .line 159
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 160
    .local v0, "dlg":Landroid/app/AlertDialog$Builder;
    const v2, 0x7f050001

    invoke-virtual {p0, v2}, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->getText(I)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 161
    const-string v2, "Yes"

    new-instance v3, Ljp/co/fwinc/madomagimamiTPS/AppliActivity$1;

    invoke-direct {v3, p0}, Ljp/co/fwinc/madomagimamiTPS/AppliActivity$1;-><init>(Ljp/co/fwinc/madomagimamiTPS/AppliActivity;)V

    invoke-virtual {v0, v2, v3}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 165
    const-string v2, "No"

    new-instance v3, Ljp/co/fwinc/madomagimamiTPS/AppliActivity$2;

    invoke-direct {v3, p0}, Ljp/co/fwinc/madomagimamiTPS/AppliActivity$2;-><init>(Ljp/co/fwinc/madomagimamiTPS/AppliActivity;)V

    invoke-virtual {v0, v2, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 174
    new-instance v2, Ljp/co/fwinc/madomagimamiTPS/AppliActivity$3;

    invoke-direct {v2, p0}, Ljp/co/fwinc/madomagimamiTPS/AppliActivity$3;-><init>(Ljp/co/fwinc/madomagimamiTPS/AppliActivity;)V

    invoke-virtual {v0, v2}, Landroid/app/AlertDialog$Builder;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog$Builder;

    .line 183
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 186
    iget-object v2, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->mainThread:Ljava/lang/Thread;

    if-eqz v2, :cond_1

    .line 187
    const/4 v2, 0x1

    iput-boolean v2, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->threadStop:Z

    .line 188
    const/4 v2, 0x0

    iput-object v2, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->mainThread:Ljava/lang/Thread;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 196
    .end local v0    # "dlg":Landroid/app/AlertDialog$Builder;
    :cond_1
    :goto_0
    return v1

    .line 194
    :catch_0
    move-exception v1

    .line 196
    :cond_2
    invoke-super {p0, p1}, Landroid/app/Activity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result v1

    goto :goto_0
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 4
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .prologue
    const/4 v2, 0x0

    .line 58
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const/16 v3, 0x1606
    invoke-virtual {p0}, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->getWindow()Landroid/view/Window;
    move-result-object v1
    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;
    move-result-object v1
    invoke-virtual {v1, v3}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 61
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->requestWindowFeature(I)Z

    .line 64
    invoke-virtual {p0}, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Ljp/co/fwinc/madomagimamiTPS/system/CommonHelper;->setContext(Landroid/content/Context;)V

    .line 70
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glRender:Ljp/co/fwinc/madomagimamiTPS/GLRender;

    if-nez v0, :cond_0

    .line 71
    new-instance v0, Landroid/opengl/GLSurfaceView;

    invoke-direct {v0, p0}, Landroid/opengl/GLSurfaceView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glSurfaceView:Landroid/opengl/GLSurfaceView;

    .line 72
    new-instance v0, Ljp/co/fwinc/madomagimamiTPS/GLRender;

    invoke-direct {v0}, Ljp/co/fwinc/madomagimamiTPS/GLRender;-><init>()V

    iput-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glRender:Ljp/co/fwinc/madomagimamiTPS/GLRender;

    .line 73
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glSurfaceView:Landroid/opengl/GLSurfaceView;

    iget-object v1, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glRender:Ljp/co/fwinc/madomagimamiTPS/GLRender;

    invoke-virtual {v0, v1}, Landroid/opengl/GLSurfaceView;->setRenderer(Landroid/opengl/GLSurfaceView$Renderer;)V

    .line 74
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glSurfaceView:Landroid/opengl/GLSurfaceView;

    invoke-virtual {v0, v2}, Landroid/opengl/GLSurfaceView;->setRenderMode(I)V

    .line 79
    invoke-virtual {p0}, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0x400

    invoke-virtual {v0, v1}, Landroid/view/Window;->addFlags(I)V

    .line 82
    new-instance v0, Landroid/widget/FrameLayout;

    invoke-direct {v0, p0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->baseLayout:Landroid/widget/FrameLayout;

    .line 83
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->baseLayout:Landroid/widget/FrameLayout;

    iget-object v1, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glSurfaceView:Landroid/opengl/GLSurfaceView;

    invoke-virtual {v0, v1}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 84
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->baseLayout:Landroid/widget/FrameLayout;

    invoke-virtual {p0, v0}, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->setContentView(Landroid/view/View;)V

    .line 87
    :cond_0
    iput-boolean v2, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->runWallpaper:Z

    .line 88
    return-void
.end method

.method public onDestroy()V
    .locals 1

    .prologue
    .line 135
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    .line 137
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glRender:Ljp/co/fwinc/madomagimamiTPS/GLRender;

    if-eqz v0, :cond_0

    .line 138
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glRender:Ljp/co/fwinc/madomagimamiTPS/GLRender;

    invoke-virtual {v0}, Ljp/co/fwinc/madomagimamiTPS/GLRender;->delete()V

    .line 142
    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->mainThread:Ljava/lang/Thread;

    .line 143
    return-void
.end method

.method protected onNewIntent(Landroid/content/Intent;)V
    .locals 0
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    .line 220
    invoke-super {p0, p1}, Landroid/app/Activity;->onNewIntent(Landroid/content/Intent;)V

    .line 222
    return-void
.end method

.method public onPause()V
    .locals 1

    .prologue
    .line 116
    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    .line 119
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->mainThread:Ljava/lang/Thread;

    if-eqz v0, :cond_0

    .line 120
    const/4 v0, 0x1

    iput-boolean v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->threadStop:Z

    .line 121
    const/4 v0, 0x0

    iput-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->mainThread:Ljava/lang/Thread;

    .line 124
    :cond_0
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glRender:Ljp/co/fwinc/madomagimamiTPS/GLRender;

    if-eqz v0, :cond_1

    .line 125
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glRender:Ljp/co/fwinc/madomagimamiTPS/GLRender;

    invoke-virtual {v0}, Ljp/co/fwinc/madomagimamiTPS/GLRender;->suspend()V

    .line 128
    :cond_1
    return-void
.end method

.method public onResume()V
    .locals 2

    .prologue
    .line 95
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 98
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->mainThread:Ljava/lang/Thread;

    if-nez v0, :cond_0

    .line 99
    const/4 v0, 0x0

    iput-boolean v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->threadStop:Z

    .line 100
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Ljp/co/fwinc/madomagimamiTPS/AppliActivity$MainThread;

    invoke-direct {v1, p0}, Ljp/co/fwinc/madomagimamiTPS/AppliActivity$MainThread;-><init>(Ljp/co/fwinc/madomagimamiTPS/AppliActivity;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    iput-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->mainThread:Ljava/lang/Thread;

    .line 101
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->mainThread:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 104
    :cond_0
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glRender:Ljp/co/fwinc/madomagimamiTPS/GLRender;

    if-eqz v0, :cond_1

    .line 105
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glRender:Ljp/co/fwinc/madomagimamiTPS/GLRender;

    invoke-virtual {v0}, Ljp/co/fwinc/madomagimamiTPS/GLRender;->resume()V

    .line 107
    :cond_1
    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 1
    .param p1, "event"    # Landroid/view/MotionEvent;

    .prologue
    .line 206
    :try_start_0
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glRender:Ljp/co/fwinc/madomagimamiTPS/GLRender;

    if-eqz v0, :cond_0

    .line 207
    iget-object v0, p0, Ljp/co/fwinc/madomagimamiTPS/AppliActivity;->glRender:Ljp/co/fwinc/madomagimamiTPS/GLRender;

    invoke-virtual {v0, p1}, Ljp/co/fwinc/madomagimamiTPS/GLRender;->touchEvent(Landroid/view/MotionEvent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 212
    :cond_0
    :goto_0
    invoke-super {p0, p1}, Landroid/app/Activity;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    return v0

    .line 209
    :catch_0
    move-exception v0

    goto :goto_0
.end method
